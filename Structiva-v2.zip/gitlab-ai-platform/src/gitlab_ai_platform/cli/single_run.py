"""単発レビュー実行(デバッグ・プロンプト改善用)のパイプライン。

方針(M1-10 [#38](https://github.com/AtsushiNi/gitlab-ai-platform/issues/38)、
`docs/architecture.md`「データフロー(MVP)」2〜9、`docs/adr/0008-cli-single-run-design.md`):

- MR Poller(定期走査・複数MR横断)を経由せず、指定された1つのproject/MRに対して
  GitLab Adapter → Workspace Manager → Review(プロンプト) → Claude Code Runner →
  Review(パース・保存) → State Store を直接結線する。このリポジトリで最初の
  エンドツーエンド結線コード。
- `execute_review`はGitLab Adapter(`GitLabReader`)・Workspace Manager・Claude Code
  Runner・State Storeの4つをProtocol型の引数として受け取る「パイプライン本体」で、
  `MrPoller`(`poller/poller.py`)と同じくテスト時は手書きフェイクを注入できる。
  `run_single_review`はそれらの具象実装(REST/git/subprocess/SQLiteまたはPostgreSQL)を`config`から
  組み立てる「合成ルート」で、CLI(`cli.main`)から呼ばれる想定。
- 各段階の例外(`GitLabAdapterError` / `WorkspaceError` / `RunnerError` / `ReviewError` /
  `StateStoreError`)は変換せずそのまま呼び出し側(`cli.main`)へ伝播させる。呼び出し側が
  終了コード・エラーメッセージへ変換する(このモジュール自身はCLI表示に関与しない)。
- `build_workspace_manager`(GitLab認証込みの`GitWorkspaceManager`組み立て)は常駐(watch)
  モード(M1-11、`cli/watch.py`)からも再利用する前提で公開している。
- Job抽象(M3-1 [#91](https://github.com/AtsushiNi/gitlab-ai-platform/issues/91)、
  `docs/adr/0016-job-abstraction.md`): `execute_review_job`が`execute_review`を
  `review`種別のJob(`JobRepository`)としてラップする。`JobRepository.enqueue`で
  `PENDING`のJobを起票し、`RUNNING`へ更新してから`execute_review`を呼び出し、成功時は
  `DONE`、`execute_review`が送出する例外発生時は`FAILED`へ更新してから元の例外を
  そのまま再送出する(呼び出し側=`build_on_detected`/CLIのエラーハンドリングは変えない)。
  `execute_review`本体(GitLab Adapter→Workspace Manager→Claude Code Runner→Review→
  State Storeの結線)自体はADR-0016の決定通り変更しない(二重レビュー防止は引き続き
  State Storeが担い、JobはState Storeとは別に「実行1回分のライフサイクル」を管理する)。
- 再レビュー(M2-2 [#81](https://github.com/AtsushiNi/gitlab-ai-platform/issues/81)):
  MR Pollerは`(project, mr_iid, commit_sha)`が未処理であれば新規pushも起票する
  (`docs/specs/poller.md`)ため、新規push自体の検出はこのモジュールの変更を必要としない。
  `execute_review`側の変更は「前回レビュー結果を索引(`review.read_index`)から探し、
  今回の指摘と突き合わせる」ことのみ。突き合わせ方式は
  [ADR-0014](../../../docs/adr/0014-re-review-finding-matching.md)参照。
"""

from __future__ import annotations

import functools
import os
import subprocess
from collections.abc import Callable, Sequence
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from ..config import GITLAB_TOKEN_ENV_KEY, Config
from ..gitlab_adapter import GitLabRestAdapter
from ..gitlab_adapter.protocol import GitLabReader
from ..job import SqliteJobRepository
from ..job.protocol import JobRepository, JobStatus
from ..logging_ import get_logger
from ..review import (
    REVIEW_JOB_TYPE,
    ReviewPaths,
    ReviewResult,
    build_review_instructions,
    build_review_job_payload,
    build_review_job_result,
    compare_findings,
    load_review_result,
    parse_review_output,
    read_index,
    review_job_payload_to_args,
    save_review,
)
from ..runner import ReviewContext, RunResult, SubprocessClaudeCodeRunner, build_prompt
from ..runner.protocol import ClaudeCodeRunner
from ..store import DuplicateReviewError, ReviewStatus, build_state_store
from ..store.errors import StateStoreError
from ..store.protocol import StateStore
from ..workspace import GitWorkspaceManager
from ..workspace.protocol import WorkspaceManager

_logger = get_logger(__name__)

# GitLabのHTTPS認証は、PATを`.git/config`やコマンド引数に残さないよう、gitのcredential
# helperプロトコル(`get`要求に対して`username=`/`password=`を標準出力へ返す)経由で都度供給する
# (`references/spike-S3-git-worktree-windows.md` §8.1)。トークンの値そのものはこの文字列には
# 含めず、環境変数名だけを埋め込む(実際の値は`build_workspace_manager`がsubprocessの
# 環境変数として注入する)。`!`で始まる値はgitがシェル経由で実行する
_CREDENTIAL_HELPER_TEMPLATE = (
    '!f() {{ echo username=oauth2; echo "password=${var}"; }}; f'
)


@dataclass(frozen=True)
class SingleRunResult:
    """1回の単発レビュー実行の結果。CLIが標準出力に表示するサマリの元データ。"""

    project: str
    mr_iid: int
    sha: str
    worktree_path: Path
    review_result: ReviewResult
    review_paths: ReviewPaths
    run_result: RunResult


def run_single_review(
    config: Config,
    project: str,
    mr_iid: int,
    *,
    timeout_seconds: int | None = None,
    allowed_tools: Sequence[str] = (),
    disallowed_tools: Sequence[str] = (),
    permission_mode: str | None = None,
) -> SingleRunResult:
    """指定した`project`/`mr_iid`を1本レビューする(合成ルート)。

    `config`からGitLab Adapter・Workspace Manager・Claude Code Runner・State Store・
    Job Repositoryの具象実装(REST/git/subprocess/SQLiteまたはPostgreSQL)を組み立て、
    `execute_review_job`(review Jobとしてラップした`execute_review`、M3-1)に委譲する。
    """
    adapter = GitLabRestAdapter(config.gitlab_url, config.gitlab_token)
    workspace = build_workspace_manager(config)
    runner = SubprocessClaudeCodeRunner(config.runner_log_dir)
    store = build_state_store(config)
    job_repo = SqliteJobRepository(config.job_db_path)
    try:
        return execute_review_job(
            job_repo,
            adapter,
            workspace,
            runner,
            store,
            config,
            project,
            mr_iid,
            timeout_seconds=timeout_seconds,
            allowed_tools=allowed_tools,
            disallowed_tools=disallowed_tools,
            permission_mode=permission_mode,
        )
    finally:
        job_repo.close()
        store.close()


def execute_review(
    adapter: GitLabReader,
    workspace: WorkspaceManager,
    runner: ClaudeCodeRunner,
    store: StateStore,
    config: Config,
    project: str,
    mr_iid: int,
    *,
    sha: str | None = None,
    timeout_seconds: int | None = None,
    allowed_tools: Sequence[str] = (),
    disallowed_tools: Sequence[str] = (),
    permission_mode: str | None = None,
) -> SingleRunResult:
    """指定した`project`/`mr_iid`を1本レビューする(パイプライン本体)。

    `adapter`/`workspace`/`runner`/`store`はいずれもProtocol型の引数として受け取り、
    具象実装(REST/git/subprocess/SQLiteまたはPostgreSQL)には依存しない。State Storeには実行開始時点で
    `RUNNING`として記録し、Workspace Manager以降のいずれかの段階で例外が発生した場合は
    `FAILED`に更新してから例外を再送出する。全段階が成功した場合のみ`DONE`に更新する。
    `config`は`runner_log_dir`等ではなく`runner_timeout_seconds`/`reviews_root`の
    デフォルト値・保存先としてのみ使う(具象実装の構築は`run_single_review`の責務)。

    `sha`は呼び出し側が既にState Storeへ起票済みのcommitがある場合(常駐(watch)モード、
    `cli/watch.py`)に指定する。省略時(単発実行)はMR取得時点の最新`merge_request.sha`を
    使う。`sha`を指定した場合、取得時点でMRがさらに進んでいても指定commitに対して
    起票・レビューを行う(先に進んだ最新commitは次回のPoller走査が別途検出・起票する)。
    これを省略して常に最新shaを使うと、Pollerが起票した`(project, mr_iid, 起票時のsha)`
    レコードがRUNNING/DONE/FAILEDへ一度も遷移しないまま孤立してしまう
    (`execute_review`が別の新しいshaで起票し直すため)。

    同一MRに対する過去のレビュー(今回とは異なるcommit)が索引に存在する場合、その最新のものを
    「前回レビュー」として今回の指摘と突き合わせ、`ReviewComparison`(修正済み/未対応/新規)を
    `save_review`に渡す(M2-2, #81。`_find_previous_review_result`参照)。前回が存在しない
    (初回レビュー)場合は比較を行わない。
    """
    # 3つとも独立したGitLab REST呼び出しなので、CLIの主用途(デバッグ時に繰り返し実行する)
    # で毎回の待ち時間を減らすため並列に取得する(逐次だと3回分のネットワーク往復が積み上がる)
    with ThreadPoolExecutor(max_workers=3) as executor:
        merge_request_future = executor.submit(
            adapter.get_merge_request, project, mr_iid
        )
        diffs_future = executor.submit(adapter.get_merge_request_diffs, project, mr_iid)
        discussions_future = executor.submit(
            adapter.list_merge_request_discussions, project, mr_iid
        )
        merge_request = merge_request_future.result()
        diffs = tuple(diffs_future.result())
        discussions = tuple(discussions_future.result())
    sha = sha if sha is not None else merge_request.sha

    # 再レビュー(M2-2, #81): 同一MRの過去レビュー(今回とは異なるcommit)のうち最新のものを
    # 「前回レビュー」として突き合わせに使う。前回が存在しなければNoneのまま(初回レビュー)
    previous_review_result = _find_previous_review_result(
        config.reviews_root, project, mr_iid, exclude_sha=sha
    )

    _ticket_running(store, project, mr_iid, sha)

    try:
        worktree = workspace.prepare(project, mr_iid, sha)

        context = ReviewContext(
            merge_request=merge_request, diffs=diffs, discussions=discussions
        )
        instructions = build_review_instructions()
        resolved_timeout = (
            timeout_seconds
            if timeout_seconds is not None
            else config.runner_timeout_seconds
        )

        run_result = runner.run(
            worktree.path,
            instructions,
            context,
            timeout_seconds=resolved_timeout,
            allowed_tools=allowed_tools,
            disallowed_tools=disallowed_tools,
            permission_mode=permission_mode,
        )
        review_result = parse_review_output(run_result)
        comparison = compare_findings(previous_review_result, review_result)

        input_prompt = build_prompt(instructions, context)
        review_paths = save_review(
            config.reviews_root,
            project,
            mr_iid,
            sha,
            review_result,
            input_prompt=input_prompt,
            run_log_path=run_result.log_path,
            comparison=comparison,
        )

        # DONEへの更新も同じtry内に含める。ここが失敗した場合もFAILEDへの更新を
        # 試みる(成功していれば再実行不要だとわかるように、失敗していれば
        # 再実行が必要だとわかるように、RUNNINGのまま放置しない)
        store.update_status(
            project,
            mr_iid,
            sha,
            ReviewStatus.DONE,
            reviewed_at=datetime.now(UTC),
            result_path=str(review_paths.dir),
        )
    except Exception:
        # 起票(RUNNING)後に失敗した場合は、再実行時に状態が追えるようFAILEDへ更新してから
        # 元の例外をそのまま再送出する(CLIが終了コードへ変換する)。FAILEDへの更新自体が
        # 失敗しても(例: DB接続不良)、元の例外(RunnerError等)をStateStoreErrorで
        # 上書きせず、ログに残した上で元の例外を優先する
        try:
            store.update_status(project, mr_iid, sha, ReviewStatus.FAILED)
        except StateStoreError as update_exc:
            _logger.error(
                "single_run.failed_status_update_failed",
                extra={
                    "project": project,
                    "mr_iid": mr_iid,
                    "sha": sha,
                    "error": str(update_exc),
                },
            )
        raise

    return SingleRunResult(
        project=project,
        mr_iid=mr_iid,
        sha=sha,
        worktree_path=worktree.path,
        review_result=review_result,
        review_paths=review_paths,
        run_result=run_result,
    )


def execute_review_job(
    job_repo: JobRepository,
    adapter: GitLabReader,
    workspace: WorkspaceManager,
    runner: ClaudeCodeRunner,
    store: StateStore,
    config: Config,
    project: str,
    mr_iid: int,
    *,
    sha: str | None = None,
    timeout_seconds: int | None = None,
    allowed_tools: Sequence[str] = (),
    disallowed_tools: Sequence[str] = (),
    permission_mode: str | None = None,
) -> SingleRunResult:
    """`execute_review`を`review`種別のJob(M3-1 [#91], ADR-0016)としてラップして実行する。

    `job_repo.enqueue`で`PENDING`のJobを起票し、`RUNNING`へ更新してから`execute_review`
    (GitLab Adapter→Workspace Manager→Claude Code Runner→Review→State Storeの結線本体、
    変更しない)を呼び出す。成功時はJobを`DONE`へ、`execute_review`が送出する例外
    (`GitLabAdapterError`/`WorkspaceError`/`RunnerError`/`ReviewError`/`StateStoreError`等)
    発生時はJobを`FAILED`へ更新してから、元の例外をそのまま再送出する
    (呼び出し側=`build_on_detected`/CLIのエラーハンドリングは変えない)。

    二重レビュー防止は引き続きState Store(`execute_review`内)が担う。Jobは
    State Storeとは別に「実行1回分のライフサイクル」だけを管理する(ADR-0016「JobとState
    Storeは別のコンポーネントとして併存させる」)。
    """
    job = job_repo.enqueue(
        REVIEW_JOB_TYPE, build_review_job_payload(project, mr_iid, sha=sha)
    )
    job = job_repo.update_status(job.id, JobStatus.RUNNING)
    # payloadを経由して引数を取り出すことで、将来Job Queue(M3-2)がJobレコードだけから
    # 実行できる形(payloadが実行に必要な情報の唯一の正)になっていることを保証する
    job_project, job_mr_iid, job_sha = review_job_payload_to_args(job.payload)

    try:
        result = execute_review(
            adapter,
            workspace,
            runner,
            store,
            config,
            job_project,
            job_mr_iid,
            sha=job_sha,
            timeout_seconds=timeout_seconds,
            allowed_tools=allowed_tools,
            disallowed_tools=disallowed_tools,
            permission_mode=permission_mode,
        )
    except Exception as exc:
        job_repo.update_status(job.id, JobStatus.FAILED, error=str(exc))
        raise

    job_repo.update_status(
        job.id,
        JobStatus.DONE,
        result=build_review_job_result(
            result.project, result.mr_iid, result.sha, str(result.review_paths.dir)
        ),
    )
    return result


def _find_previous_review_result(
    reviews_root: str, project: str, mr_iid: int, *, exclude_sha: str
) -> ReviewResult | None:
    """再レビュー(M2-2, #81)時に突き合わせる「前回レビュー」を索引から探す。

    同一`(project, mr_iid)`の過去レビューのうち、`exclude_sha`(今回のcommit)とは異なる
    commitで最も新しいもの(`reviewed_at`が最大のもの)を前回とする。索引の絞り込みは
    `review/index.py`自身の責務ではなくCLI側の責務(`docs/specs/review-output.md`「非対象」)
    のため、ここで行う。該当が無ければ(初回レビュー、または`sha`を変えない再実行のみ)`None`。
    """
    candidates = [
        entry
        for entry in read_index(reviews_root)
        if entry.project == project
        and entry.mr_iid == mr_iid
        and entry.sha != exclude_sha
    ]
    if not candidates:
        return None

    latest = max(candidates, key=lambda entry: entry.reviewed_at)
    try:
        return load_review_result(reviews_root, project, mr_iid, latest.sha)
    except (OSError, ValueError, KeyError) as exc:
        # 索引にはあるが結果ファイルが読めない(壊れている/消えている)場合、再レビューの
        # 比較機能だけを諦め、レビュー自体は通常通り継続する(index.pyが壊れた行をスキップして
        # 全体の読み込みを止めないのと同じ耐性の考え方)
        _logger.warning(
            "single_run.previous_review_load_failed",
            extra={
                "project": project,
                "mr_iid": mr_iid,
                "sha": latest.sha,
                "error": str(exc),
            },
        )
        return None


def _ticket_running(store: StateStore, project: str, mr_iid: int, sha: str) -> None:
    """`(project, mr_iid, sha)`を`RUNNING`として起票する。

    単発実行は同一commitへの再実行(プロンプト調整のたびに繰り返す運用)を想定しているため、
    既存レコードがあれば(MR Pollerのように無視するのではなく)`RUNNING`へ更新して実行を続ける。
    """
    try:
        store.create(project, mr_iid, sha, status=ReviewStatus.RUNNING)
    except DuplicateReviewError:
        store.update_status(project, mr_iid, sha, ReviewStatus.RUNNING)


def _clone_url_for(gitlab_url: str) -> Callable[[str], str]:
    def build(project: str) -> str:
        return f"{gitlab_url}/{project}.git"

    return build


def _credential_helper() -> str:
    return _CREDENTIAL_HELPER_TEMPLATE.format(var=GITLAB_TOKEN_ENV_KEY)


def build_workspace_manager(config: Config) -> GitWorkspaceManager:
    token_env = {GITLAB_TOKEN_ENV_KEY: config.gitlab_token}
    run_with_token = functools.partial(subprocess.run, env={**os.environ, **token_env})

    return GitWorkspaceManager(
        config.workspace_root,
        _clone_url_for(config.gitlab_url),
        max_disk_bytes=config.workspace_max_disk_mb * 1024 * 1024,
        # 空値で既存のcredential.helper(実行環境の~/.gitconfig等に設定済みのものが
        # あれば)を一旦クリアしてから、PAT供給用のものだけを設定する。gitは
        # credential.helperを複数個「追加」していく仕組みのため、クリアしないと
        # 既存の設定が先に応答してPATが使われない可能性がある
        git_config=(
            ("credential.helper", ""),
            ("credential.helper", _credential_helper()),
        ),
        run=run_with_token,
    )


__all__ = [
    "SingleRunResult",
    "build_workspace_manager",
    "execute_review",
    "execute_review_job",
    "run_single_review",
]
